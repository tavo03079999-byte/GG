import React from 'react';
import { Sparkles, Flame, BookOpen, PlusCircle, Play, ChevronRight, Award, Compass, Shield } from 'lucide-react';
import { BookCollection, ReelShort } from '../types';
import { soundManager } from '../utils/audioEffects';

interface HomeTabProps {
  collections: BookCollection[];
  onSelectCollection: (collectionId: string) => void;
  onOpenLibrary: () => void;
  onOpenUpload: () => void;
  onPlayReel: (short: ReelShort, collectionId: string) => void;
  quizPoints: number;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  collections,
  onSelectCollection,
  onOpenLibrary,
  onOpenUpload,
  onPlayReel,
  quizPoints,
}) => {
  const totalReels = collections.reduce((acc, c) => acc + c.shorts.length, 0);

  // Pick a featured daily reel from first collection
  const featuredShort = collections[0]?.shorts[0];

  return (
    <div className="w-full max-w-2xl mx-auto px-4 pt-6 pb-28 text-white animate-fade-in space-y-6">
      {/* Brand & Metrics Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 flex items-center justify-center font-black text-zinc-950 shadow-md shadow-amber-500/20 select-none">
            <span className="text-xs font-black tracking-tight">GG</span>
            <span className="text-base font-serif font-black ml-0.5">✝</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-lg text-white">GG <span className="text-amber-400 font-serif">✝</span></span>
              <span className="text-amber-400 font-mono text-[9px] bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 rounded font-bold">REELS</span>
            </div>
            <p className="text-[11px] text-zinc-400">Sabiduría en micro-lecciones</p>
          </div>
        </div>

        {/* Quick Streak & XP Badges */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold shadow-sm">
            <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>3 Días</span>
          </div>
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>{quizPoints} XP</span>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => {
            soundManager.playPop();
            onOpenLibrary();
          }}
          className="p-3.5 rounded-2xl bg-zinc-900/90 hover:bg-zinc-850 border border-zinc-800 hover:border-amber-500/40 text-left transition-all group flex items-center justify-between"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-zinc-200">Biblioteca</p>
              <p className="text-[10px] text-zinc-500">{collections.length} Libros guardados</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-amber-400 transition-colors" />
        </button>

        <button
          onClick={() => {
            soundManager.playPop();
            onOpenUpload();
          }}
          className="p-3.5 rounded-2xl bg-zinc-900/90 hover:bg-zinc-850 border border-zinc-800 hover:border-amber-500/40 text-left transition-all group flex items-center justify-between"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20">
              <PlusCircle className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-zinc-200">Subir Archivo</p>
              <p className="text-[10px] text-zinc-500">Crear reels de PDF</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-amber-400 transition-colors" />
        </button>
      </div>

      {/* Featured Lesson of the Day Banner */}
      {featuredShort && (
        <div className="relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-amber-950/40 via-zinc-900 to-zinc-950 border border-amber-500/30 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/15 px-2.5 py-0.5 rounded-full border border-amber-500/30 flex items-center gap-1">
              <Sparkles className="w-3 h-3 fill-amber-400" /> Lección Destacada de Hoy
            </span>
            <span className="text-xs text-zinc-400">📖 {featuredShort.bookTitle}</span>
          </div>

          <div>
            <h3 className="text-base font-black text-white line-clamp-1">
              {featuredShort.title}
            </h3>
            <p className="text-xs text-zinc-300 italic line-clamp-2 mt-1">
              "{featuredShort.hook || featuredShort.quote}"
            </p>
          </div>

          <div className="pt-1 flex items-center justify-between">
            <p className="text-[10px] text-zinc-500">
              🎯 {featuredShort.actionableTakeaway}
            </p>
            <button
              onClick={() => onPlayReel(featuredShort, collections[0].id)}
              className="px-4 py-2 rounded-xl font-bold text-xs bg-amber-400 hover:bg-amber-300 text-zinc-950 flex items-center gap-1.5 transition-colors shadow-md shadow-amber-500/20"
            >
              <Play className="w-3.5 h-3.5 fill-current" /> Ver Reel
            </button>
          </div>
        </div>
      )}

      {/* Book Collections Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-black text-white flex items-center gap-1.5">
            <BookOpen className="w-4 h-4 text-amber-400" />
            Colecciones de Libros ({collections.length})
          </h2>
          <button
            onClick={() => onSelectCollection('all')}
            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
          >
            <span>Ver Modo Alternado</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {collections.map((c) => (
            <div
              key={c.id}
              onClick={() => onSelectCollection(c.id)}
              className="p-4 rounded-2xl bg-zinc-900/80 hover:bg-zinc-850 border border-zinc-800 hover:border-amber-500/40 transition-all cursor-pointer group flex flex-col justify-between space-y-3 shadow-sm hover:shadow-md"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] text-zinc-500 mb-1">
                  <span className="font-bold text-amber-400 uppercase tracking-wide">{c.category || 'Desarrollo'}</span>
                  <span>{c.shorts.length} Shorts</span>
                </div>
                <h3 className="text-sm font-black text-white group-hover:text-amber-300 transition-colors line-clamp-1">
                  {c.title}
                </h3>
                <p className="text-[11px] text-zinc-400 truncate mt-0.5">
                  Por {c.author}
                </p>
                <p className="text-xs text-zinc-500 line-clamp-2 mt-2 leading-relaxed">
                  {c.summary}
                </p>
              </div>

              <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between text-xs">
                <span className="text-[10px] text-zinc-400">100% interactivo</span>
                <span className="font-bold text-amber-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-1 text-[11px]">
                  Ver Reels <Play className="w-3 h-3 fill-current" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
