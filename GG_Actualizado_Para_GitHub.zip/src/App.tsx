import React, { useState, useEffect, useRef, useCallback } from 'react';
import { BookCollection, ReelShort } from './types';
import { DEFAULT_BOOK_COLLECTIONS } from './data/defaultBooks';
import { ReelCard } from './components/ReelCard';
import { VideoCanvasPlayer } from './components/VideoCanvasPlayer';
import { HeaderBar } from './components/HeaderBar';
import { QuizModal } from './components/QuizModal';
import { DeepDiveModal } from './components/DeepDiveModal';
import { UploadModal } from './components/UploadModal';
import { LibraryModal } from './components/LibraryModal';
import { ViralTrendsModal } from './components/ViralTrendsModal';
import { MusicSelectorModal } from './components/MusicSelectorModal';
import { BottomNav, NavTab } from './components/BottomNav';
import { SearchTab } from './components/SearchTab';
import { ProfileTab } from './components/ProfileTab';
import { HomeTab } from './components/HomeTab';
import { UploadTab } from './components/UploadTab';
import { speechService, SpeechPlayerState } from './utils/speechService';
import { soundManager } from './utils/audioEffects';
import { musicEngine, MusicTrackId } from './utils/bgmSynthesizer';
import { ViralWebTrend } from './types';
import {
  ChevronDown,
  ChevronUp,
  Sparkles,
  HelpCircle,
  Volume2,
  BookOpen,
  Keyboard,
  Compass,
  Flame
} from 'lucide-react';

export default function App() {
  // Navigation Tab State
  const [currentTab, setCurrentTab] = useState<NavTab>('reels');

  // Collections state
  const [collections, setCollections] = useState<BookCollection[]>(() => {
    try {
      const saved = localStorage.getItem('scrolllearn_collections');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {}
    return DEFAULT_BOOK_COLLECTIONS;
  });

  // Default to 'all' so books are automatically interleaved and varied across down-scrolls
  const [currentCollectionId, setCurrentCollectionId] = useState<string>('all');
  const [shuffleSeed, setShuffleSeed] = useState<number>(0);

  const [currentReelIndex, setCurrentReelIndex] = useState<number>(0);

  // Audio state
  const [isAudioPlaying, setIsAudioPlaying] = useState<boolean>(false);
  const [audioProgress, setAudioProgress] = useState<number>(0);
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState<number>(0);
  const [autoPlayAudio, setAutoPlayAudio] = useState<boolean>(false);

  // Auto-scroll Hands-Free Mode
  const [autoScroll, setAutoScroll] = useState<boolean>(false);

  // View Mode: 'card' (interactive vertical cards) | 'video' (60FPS animated video with kinetic captions)
  const [viewMode, setViewMode] = useState<'card' | 'video'>('card');

  // Music & Reel Soundtrack state
  const [activeTrackId, setActiveTrackId] = useState<MusicTrackId>('phonk');
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(true);
  const [isMusicSelectorOpen, setIsMusicSelectorOpen] = useState<boolean>(false);

  // Modals state
  const [activeQuizShort, setActiveQuizShort] = useState<ReelShort | null>(null);
  const [activeDeepDiveShort, setActiveDeepDiveShort] = useState<ReelShort | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);
  const [isLibraryModalOpen, setIsLibraryModalOpen] = useState<boolean>(false);
  const [isViralTrendsOpen, setIsViralTrendsOpen] = useState<boolean>(false);
  const [viralTrendForUpload, setViralTrendForUpload] = useState<string>('');

  // Gamification & Saved
  const [quizPoints, setQuizPoints] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('scrolllearn_xp')) || 10;
    } catch {
      return 10;
    }
  });

  const [savedShortIds, setSavedShortIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('scrolllearn_saved');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Compute interleaved shorts across all collections (alternating 1 from each book)
  const interleavedShorts = React.useMemo(() => {
    const result: ReelShort[] = [];
    const maxLen = Math.max(...collections.map((c) => c.shorts.length), 0);

    const activeColls = [...collections];
    if (shuffleSeed > 0) {
      activeColls.sort((a, b) => {
        const hashA = (a.id.length * 31 + shuffleSeed * 19) % 100;
        const hashB = (b.id.length * 31 + shuffleSeed * 19) % 100;
        return hashA - hashB;
      });
    }

    for (let i = 0; i < maxLen; i++) {
      for (const c of activeColls) {
        if (c.shorts[i]) {
          result.push(c.shorts[i]);
        }
      }
    }
    return result;
  }, [collections, shuffleSeed]);

  // Current active collection & shorts
  const isInterleavedMode = currentCollectionId === 'all';

  const currentCollection: BookCollection = isInterleavedMode
    ? {
        id: 'all',
        title: '🔀 Para Ti (Libros Alternados)',
        author: `${collections.length} Libros en Variación`,
        category: 'Feed Alternado',
        summary: 'Reels intercalados de todos tus libros y PDFs para máxima variedad y aprendizaje continuo.',
        coverGradient: 'from-amber-600 via-rose-700 to-indigo-900',
        shorts: interleavedShorts,
      }
    : collections.find((c) => c.id === currentCollectionId) || collections[0];

  const shorts = isInterleavedMode ? interleavedShorts : currentCollection.shorts;
  const currentShort = shorts[currentReelIndex] || shorts[0];

  // Touch gesture tracking for vertical swipe
  const touchStartY = useRef<number>(0);
  const touchEndY = useRef<number>(0);
  const isWheeling = useRef<boolean>(false);
  const wheelTimeout = useRef<number | null>(null);

  // Save collections to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('scrolllearn_collections', JSON.stringify(collections));
    } catch (e) {}
  }, [collections]);

  // Save XP to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('scrolllearn_xp', String(quizPoints));
    } catch (e) {}
  }, [quizPoints]);

  // Save Bookmarks to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('scrolllearn_saved', JSON.stringify(savedShortIds));
    } catch (e) {}
  }, [savedShortIds]);

  // All saved shorts
  const allSavedShorts = React.useMemo(() => {
    const list: ReelShort[] = [];
    collections.forEach((c) => {
      c.shorts.forEach((s) => {
        if (savedShortIds.includes(s.id)) {
          list.push(s);
        }
      });
    });
    return list;
  }, [collections, savedShortIds]);

  // Handle Reel Navigation
  const handleNextReel = useCallback(() => {
    if (currentReelIndex < shorts.length - 1) {
      soundManager.playSwoosh();
      speechService.stop();
      setIsAudioPlaying(false);
      setCurrentReelIndex((prev) => prev + 1);
    }
  }, [currentReelIndex, shorts.length]);

  const handlePrevReel = useCallback(() => {
    if (currentReelIndex > 0) {
      soundManager.playSwoosh();
      speechService.stop();
      setIsAudioPlaying(false);
      setCurrentReelIndex((prev) => prev - 1);
    }
  }, [currentReelIndex]);

  // Shuffle Feed
  const handleShuffleFeed = () => {
    soundManager.playPop();
    setShuffleSeed((prev) => prev + 1);
    setCurrentReelIndex(0);
    speechService.stop();
    setIsAudioPlaying(false);
  };

  // Select reel from Search / Home / Profile tabs
  const handleSelectReelFromTab = (short: ReelShort, collectionId: string) => {
    speechService.stop();
    setIsAudioPlaying(false);
    if (collectionId === 'all') {
      setCurrentCollectionId('all');
      const idx = interleavedShorts.findIndex((s) => s.id === short.id);
      setCurrentReelIndex(Math.max(0, idx));
    } else {
      setCurrentCollectionId(collectionId);
      const parent = collections.find((c) => c.id === collectionId);
      if (parent) {
        const idx = parent.shorts.findIndex((s) => s.id === short.id);
        setCurrentReelIndex(Math.max(0, idx));
      }
    }
    setCurrentTab('reels');
  };

  // Toggle Save / Bookmark
  const handleToggleSave = () => {
    soundManager.playPop();
    const id = currentShort.id;
    setSavedShortIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleRemoveSaved = (shortId: string) => {
    soundManager.playPop();
    setSavedShortIds((prev) => prev.filter((id) => id !== shortId));
  };

  // Add new collection generated by Gemini
  const handleAddCollection = (newColl: BookCollection) => {
    setCollections((prev) => [newColl, ...prev]);
    setCurrentCollectionId(newColl.id);
    setCurrentReelIndex(0);
  };

  const handleAddCollectionFromUpload = (newColl: BookCollection) => {
    handleAddCollection(newColl);
    setCurrentTab('reels');
  };

  // Auto-scroll Timer Effect
  useEffect(() => {
    if (!autoScroll || currentTab !== 'reels') return;
    const duration = isAudioPlaying ? 35000 : 15000;
    const timer = setTimeout(() => {
      if (currentReelIndex < shorts.length - 1) {
        handleNextReel();
      } else {
        setAutoScroll(false);
      }
    }, duration);

    return () => clearTimeout(timer);
  }, [autoScroll, currentReelIndex, shorts.length, handleNextReel, isAudioPlaying, currentTab]);

  // Audio Speech Service Setup & Ducking
  const handleToggleAudio = useCallback(() => {
    soundManager.playPop();
    if (isAudioPlaying) {
      speechService.stop();
      setIsAudioPlaying(false);
      musicEngine.setDucking(false);
    } else {
      if (!currentShort) return;
      speechService.speakReel(currentShort, {
        onStateChange: (state: SpeechPlayerState) => {
          setIsAudioPlaying(state.isPlaying);
          setAudioProgress(state.progress);
          setCurrentPhraseIndex(state.currentPhraseIndex);
          musicEngine.setDucking(state.isPlaying);
        },
        onEnd: () => {
          setIsAudioPlaying(false);
          setAudioProgress(100);
          musicEngine.setDucking(false);
        },
      });
    }
  }, [isAudioPlaying, currentShort]);

  // Keyboard navigation
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (currentTab !== 'reels') return;
      if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        handleNextReel();
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        handlePrevReel();
      } else if (e.key === ' ' || e.key === 'Spacebar') {
        e.preventDefault();
        handleToggleAudio();
      } else if (e.key === 'q' || e.key === 'Q') {
        e.preventDefault();
        if (currentShort) setActiveQuizShort(currentShort);
      }
    },
    [handleNextReel, handlePrevReel, handleToggleAudio, currentShort, currentTab]
  );

  // Swipe gesture handling for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    if (currentTab !== 'reels') return;
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (currentTab !== 'reels') return;
    touchEndY.current = e.changedTouches[0].clientY;
    const diff = touchStartY.current - touchEndY.current;

    // Minimum swipe threshold (50px)
    if (diff > 50) {
      handleNextReel();
    } else if (diff < -50) {
      handlePrevReel();
    }
  };

  // Mouse wheel scroll handling
  const handleWheel = (e: React.WheelEvent) => {
    if (currentTab !== 'reels') return;
    if (isWheeling.current) return;

    if (Math.abs(e.deltaY) > 40) {
      isWheeling.current = true;
      if (e.deltaY > 0) {
        handleNextReel();
      } else {
        handlePrevReel();
      }

      if (wheelTimeout.current) clearTimeout(wheelTimeout.current);
      wheelTimeout.current = window.setTimeout(() => {
        isWheeling.current = false;
      }, 650);
    }
  };

  // Start BGM on first interaction
  useEffect(() => {
    const handleFirstClick = () => {
      if (isMusicPlaying) {
        musicEngine.start('phonk');
      }
      window.removeEventListener('click', handleFirstClick);
    };
    window.addEventListener('click', handleFirstClick, { once: true });
    return () => window.removeEventListener('click', handleFirstClick);
  }, [isMusicPlaying]);

  return (
    <div
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onWheel={handleWheel}
      className="relative min-h-screen w-full bg-zinc-950 text-white flex flex-col justify-between overflow-x-hidden font-sans select-none focus:outline-none"
    >
      {/* Tab 1: Inicio */}
      {currentTab === 'home' && (
        <HomeTab
          collections={collections}
          onSelectCollection={(colId) => {
            setCurrentCollectionId(colId);
            setCurrentReelIndex(0);
            setCurrentTab('reels');
          }}
          onOpenLibrary={() => setIsLibraryModalOpen(true)}
          onOpenUpload={() => setCurrentTab('upload')}
          onPlayReel={handleSelectReelFromTab}
          quizPoints={quizPoints}
        />
      )}

      {/* Tab 2: Buscar / Explorar (Matching Screenshot 2) */}
      {currentTab === 'search' && (
        <SearchTab
          collections={collections}
          onSelectReel={handleSelectReelFromTab}
        />
      )}

      {/* Tab 3: Subir (Matching Screenshot 3) */}
      {currentTab === 'upload' && (
        <UploadTab
          onAddCollection={handleAddCollectionFromUpload}
          onJumpToReels={() => setCurrentTab('reels')}
        />
      )}

      {/* Tab 4: Reels (Down-scrolling view matching Screenshots 1 & 4) */}
      {currentTab === 'reels' && (
        <>
          <HeaderBar
            collections={collections}
            currentCollection={currentCollection}
            onSelectCollection={(id) => {
              setCurrentCollectionId(id);
              setCurrentReelIndex(0);
              speechService.stop();
              setIsAudioPlaying(false);
            }}
            onOpenUpload={() => setCurrentTab('upload')}
            onOpenLibrary={() => setIsLibraryModalOpen(true)}
            onOpenViralTrends={() => setIsViralTrendsOpen(true)}
            onOpenMusicSelector={() => setIsMusicSelectorOpen(true)}
            isMusicPlaying={isMusicPlaying}
            musicTrackName={musicEngine.getCurrentTrack().name}
            autoScroll={autoScroll}
            onToggleAutoScroll={() => {
              soundManager.playPop();
              setAutoScroll(!autoScroll);
            }}
            isMuted={!isAudioPlaying}
            onToggleMute={handleToggleAudio}
            quizPoints={quizPoints}
            viewMode={viewMode}
            onToggleViewMode={() => {
              soundManager.playPop();
              setViewMode(viewMode === 'card' ? 'video' : 'card');
            }}
            isInterleaved={isInterleavedMode}
            onShuffleFeed={handleShuffleFeed}
          />

          {/* Main App Canvas */}
          <div className="relative flex-1 pt-14 pb-14 px-2 sm:px-4 flex items-center justify-center overflow-hidden">
            {/* Desktop Left Side Guides */}
            <div className="hidden lg:flex flex-col gap-3 absolute left-6 top-1/2 -translate-y-1/2 text-xs text-zinc-500 max-w-[200px]">
              {/* Music Soundtrack Quick Trigger */}
              <div
                onClick={() => setIsMusicSelectorOpen(true)}
                className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs cursor-pointer hover:bg-amber-500/20 transition-all space-y-1 shadow-lg"
              >
                <div className="flex items-center justify-between font-bold">
                  <span className="flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-amber-400" /> Canción del Reel
                  </span>
                  <span className="text-[9px] bg-amber-500/30 px-1.5 py-0.5 rounded uppercase">Beat</span>
                </div>
                <p className="text-[11px] text-zinc-300 font-semibold truncate">
                  {musicEngine.getCurrentTrack().name}
                </p>
              </div>

              {/* Radar Web Quick Trigger */}
              <div
                onClick={() => setIsViralTrendsOpen(true)}
                className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-rose-200 text-xs cursor-pointer hover:bg-rose-900/50 transition-all space-y-1 shadow-lg"
              >
                <div className="flex items-center justify-between font-bold text-rose-300">
                  <span className="flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-rose-400" /> Radar de Tendencias
                  </span>
                  <span className="text-[9px] bg-rose-500/30 px-1.5 py-0.5 rounded uppercase">Web</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Ideas virales de TikTok/Reels para adaptar a tu PDF.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 backdrop-blur-md space-y-2">
                <span className="font-bold text-zinc-300 flex items-center gap-1.5 text-xs">
                  <Keyboard className="w-3.5 h-3.5 text-amber-400" /> Atajos Rápidos
                </span>
                <div className="flex items-center justify-between text-[11px]">
                  <span>Siguiente Reel</span>
                  <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700 text-zinc-300">↓</kbd>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span>Reel Anterior</span>
                  <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700 text-zinc-300">↑</kbd>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span>Voz Narrador</span>
                  <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700 text-zinc-300">Espacio</kbd>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span>Reto Quiz</span>
                  <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700 text-zinc-300">Q</kbd>
                </div>
              </div>
            </div>

            {/* Center Vertical Reel Stage */}
            <div className="relative w-full h-[calc(100vh-130px)] max-h-[780px] max-w-[420px] flex items-center justify-center">
              {viewMode === 'video' ? (
                <VideoCanvasPlayer
                  key={`vid-${currentShort.id}`}
                  short={{
                    ...currentShort,
                    isSaved: savedShortIds.includes(currentShort.id),
                  }}
                  onNextReel={handleNextReel}
                  onPrevReel={handlePrevReel}
                  onOpenMusicSelector={() => setIsMusicSelectorOpen(true)}
                />
              ) : (
                <ReelCard
                  key={currentShort.id}
                  short={{
                    ...currentShort,
                    isSaved: savedShortIds.includes(currentShort.id),
                  }}
                  index={currentReelIndex}
                  total={shorts.length}
                  isActive={true}
                  isAudioPlaying={isAudioPlaying}
                  audioProgress={audioProgress}
                  currentPhraseIndex={currentPhraseIndex}
                  onToggleAudio={handleToggleAudio}
                  onOpenQuiz={() => setActiveQuizShort(currentShort)}
                  onOpenDeepDive={() => setActiveDeepDiveShort(currentShort)}
                  onToggleSave={handleToggleSave}
                  onNextReel={handleNextReel}
                  onPrevReel={handlePrevReel}
                  isMusicPlaying={isMusicPlaying}
                  musicTrackName={musicEngine.getCurrentTrack().name}
                  onToggleMusic={() => {
                    soundManager.playPop();
                    setIsMusicPlaying(!isMusicPlaying);
                  }}
                  onOpenMusicSelector={() => setIsMusicSelectorOpen(true)}
                />
              )}
            </div>

            {/* Desktop Right Side: Book Chapters & Quick Overview */}
            <div className="hidden lg:flex flex-col gap-2 absolute right-6 top-1/2 -translate-y-1/2 text-xs text-zinc-400 max-w-[220px]">
              <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 backdrop-blur-md space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-200 flex items-center gap-1.5 text-xs">
                    <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                    {isInterleavedMode ? 'Feed Alternado' : 'En este Libro'}
                  </span>
                  <span className="text-[10px] bg-zinc-800 px-2 py-0.5 rounded-full text-zinc-300">
                    {currentReelIndex + 1}/{shorts.length}
                  </span>
                </div>

                <div className="space-y-1.5 max-h-[280px] overflow-y-auto no-scrollbar pr-1">
                  {shorts.map((s, idx) => (
                    <button
                      key={s.id}
                      onClick={() => {
                        speechService.stop();
                        setIsAudioPlaying(false);
                        setCurrentReelIndex(idx);
                      }}
                      className={`w-full text-left p-2 rounded-xl text-[11px] font-medium transition-all flex items-center gap-2 ${
                        idx === currentReelIndex
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                          : 'hover:bg-zinc-800/80 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      <span className="w-4 h-4 rounded-full bg-zinc-800 text-zinc-300 flex items-center justify-center text-[9px] shrink-0">
                        {idx + 1}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate">{s.title}</p>
                        {isInterleavedMode && s.bookTitle && (
                          <p className="text-[9px] text-zinc-500 truncate font-normal">
                            📖 {s.bookTitle}
                          </p>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Tab 5: Perfil / Guardados (Matching Screenshot 5) */}
      {currentTab === 'profile' && (
        <ProfileTab
          quizPoints={quizPoints}
          collections={collections}
          savedShorts={allSavedShorts}
          onSelectReel={handleSelectReelFromTab}
          onRemoveSaved={handleRemoveSaved}
          isMusicPlaying={isMusicPlaying}
          onToggleMusic={() => {
            soundManager.playPop();
            setIsMusicPlaying(!isMusicPlaying);
          }}
        />
      )}

      {/* Persistent Bottom Navigation Bar (5 tabs) */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        savedCount={savedShortIds.length}
      />

      {/* Modals */}
      {activeQuizShort && (
        <QuizModal
          quiz={activeQuizShort.quiz}
          reelTitle={activeQuizShort.title}
          isOpen={!!activeQuizShort}
          onClose={() => setActiveQuizShort(null)}
          onCorrect={() => {
            setQuizPoints((prev) => prev + 10);
          }}
        />
      )}

      {activeDeepDiveShort && (
        <DeepDiveModal
          short={activeDeepDiveShort}
          isOpen={!!activeDeepDiveShort}
          onClose={() => setActiveDeepDiveShort(null)}
        />
      )}

      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onAddCollection={handleAddCollectionFromUpload}
        initialViralTrend={viralTrendForUpload}
      />

      <ViralTrendsModal
        isOpen={isViralTrendsOpen}
        onClose={() => setIsViralTrendsOpen(false)}
        currentBookTitle={currentCollection.title}
        onApplyTrendToGenerator={(trend) => {
          setViralTrendForUpload(trend.trendName);
          setIsUploadModalOpen(true);
        }}
      />

      <MusicSelectorModal
        isOpen={isMusicSelectorOpen}
        onClose={() => setIsMusicSelectorOpen(false)}
        activeTrackId={activeTrackId}
        onSelectTrack={(trackId) => {
          setActiveTrackId(trackId);
          musicEngine.switchTrack(trackId);
        }}
        isMusicPlaying={isMusicPlaying}
        onToggleMusicPlay={() => {
          setIsMusicPlaying(!isMusicPlaying);
        }}
      />

      <LibraryModal
        isOpen={isLibraryModalOpen}
        onClose={() => setIsLibraryModalOpen(false)}
        collections={collections}
        currentCollectionId={currentCollectionId}
        onSelectCollection={(id) => {
          setCurrentCollectionId(id);
          setCurrentReelIndex(0);
          speechService.stop();
          setIsAudioPlaying(false);
        }}
        savedShorts={allSavedShorts}
        onSelectShort={(s) => {
          const parent = collections.find((c) => c.shorts.some((item) => item.id === s.id));
          if (parent) {
            handleSelectReelFromTab(s, parent.id);
          }
        }}
        onDeleteCollection={(id) => {
          setCollections((prev) => prev.filter((c) => c.id !== id));
          if (currentCollectionId === id) {
            setCurrentCollectionId('babilonia');
            setCurrentReelIndex(0);
          }
        }}
        quizPoints={quizPoints}
      />
    </div>
  );
}
